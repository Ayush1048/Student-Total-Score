#  Calculate Student-Total-Score using LinearRegression
Prediction of student Total score by using Linear regression and check prediction with the orignal Total score
